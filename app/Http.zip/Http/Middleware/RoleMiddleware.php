<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Tymon\JWTAuth\Facades\JWTAuth;
use Symfony\Component\HttpFoundation\Response;

class RoleMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     * @param  string  $role
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function handle(Request $request, Closure $next, $role)
    {
        try {
            // Ambil pengguna berdasarkan token JWT
            $user = JWTAuth::parseToken()->authenticate();
            \Log::info('User authenticated', ['user' => $user]);
        } catch (\Exception $e) {
            // Jika token tidak valid atau tidak ada, kembalikan response Unauthorized
            return response()->json(['message' => 'Unauthorized'], 401);
        }

        // Cek apakah role pengguna sesuai dengan yang dibutuhkan
        if ($user->role !== $role) {
            return response()->json(['message' => $user->role, 'role'=> $role], 403); // Jika role tidak sesuai
        }

        // Lanjutkan request ke middleware berikutnya jika role valid
        return $next($request);
    }
}
