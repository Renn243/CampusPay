<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use App\Models\Mahasiswa;

class AdminMahasiswaController extends Controller
{
     public function index(Request $request)
    {
        // Ambil jumlah per halaman dari query ?per_page=10, default 10
        $perPage = $request->query('per_page', 10);

        $listMahasiswa = Mahasiswa::paginate($perPage);

        return response()->json($listMahasiswa, 200);
    }

    // Tampilkan detail transaksi tertentu (pembayaran, rincian, dan info tagihan)
    public function show($id)
    {

        $mahasiswa = Mahasiswa::with(['user'])
                        ->find($id);

        if (!$mahasiswa) {
            return response()->json(['message' => 'Mahasiswa tidak ditemukan'], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $mahasiswa
        ]);
    }

    // Update Profile Mahasiswa
    public function updateProfileMahasiswa(Request $request, $id)
    {
        // Validasi input data
        $validated = $request->validate([
            'status' => 'required|in:aktif,non-aktif', // Validasi status
            'nama_mahasiswa' => 'nullable|string|max:255', 
            'tanggal_lahir' => 'nullable|date', 
            'alamat' => 'nullable|string|max:255',
            // 'jenis_kelamin',
            // 'agama',
            // 'tempat_lahir',
            // 'no_telp'
        ]);

        // Mencari mahasiswa berdasarkan ID
        $mahasiswa = Mahasiswa::find($id);

        // Cek jika mahasiswa tidak ditemukan
        if (!$mahasiswa) {
            return response()->json([
                'success' => false,
                'message' => 'Mahasiswa tidak ditemukan',
            ], 404);
        }

        // Update data mahasiswa
        $mahasiswa->update([
            'status' => $request->status, // Update status
            'nama_mahasiswa' => $request->nama_mahasiswa ?? $mahasiswa->nama_mahasiswa, // Jika nama tidak ada, tetap menggunakan yang lama
            'tanggal_lahir' => $request->tanggal_lahir ?? $mahasiswa->tanggal_lahir, // Jika tanggal lahir tidak ada, tetap menggunakan yang lama
            'alamat' => $request->alamat ?? $mahasiswa->alamat, // Jika alamat tidak ada, tetap menggunakan yang lama
        ]);

        // Return response sukses
        return response()->json([
            'success' => true,
            'message' => 'Profile mahasiswa berhasil diperbarui',
            'data' => $mahasiswa,
        ], 200);
    }
}
