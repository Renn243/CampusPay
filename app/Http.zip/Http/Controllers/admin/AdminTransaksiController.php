<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use App\Models\Transaksi;
use App\Models\Mahasiswa;

class AdminTransaksiController extends Controller
{
     public function index(Request $request)
    {
        // Ambil jumlah per halaman dari query ?per_page=10, default 10
        $perPage = $request->query('per_page', 10);

        $tagihan = Transaksi::with(['mahasiswa', 'tagihan'])->paginate($perPage);

        return response()->json($tagihan, 200);
    }

    // Tampilkan detail transaksi tertentu (pembayaran, rincian, dan info tagihan)
    public function show($id)
    {

        $transaksiById = Transaksi::with(['mahasiswa', 'tagihan'])  // Pastikan relasi 'mahasiswa' dan 'tagihan' sudah didefinisikan
                        ->where('id_transaksi', $id)  // Filter berdasarkan id_mahasiswa
                        ->get();

        if (!$transaksiById) {
            return response()->json(['message' => 'Transaksi tidak ditemukan'], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $transaksiById
        ]);
    }

    // Update status transaksi berdasarkan request status admin (sukses, gagal)
    public function updateStatusPembayaran(Request $request, $id)
    {
        $transaksiById = Transaksi::with(['mahasiswa', 'tagihan'])  // Pastikan relasi 'mahasiswa' dan 'tagihan' sudah didefinisikan
                        ->where('id_transaksi', $id)  // Filter berdasarkan id_mahasiswa
                        ->first();

        if (!$transaksiById) {
            return response()->json(['message' => 'Transaksi tidak ditemukan'], 404);
        }

        if ($transaksiById->status === 'sukses') {
            return response()->json(['message' => 'Transaksi sudah dibayar'], 400);
        }

        $transaksiById->update([
            'status'        => $request->status,
            'tanggal_bayar' => Carbon::now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Pembayaran berhasil',
            'data' => $transaksiById
        ]);
    }
}
