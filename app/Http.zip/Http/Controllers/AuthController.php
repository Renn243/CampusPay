<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Mahasiswa;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Tymon\JWTAuth\Facades\JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;

class AuthController extends Controller
{
    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'username' => 'required|string|unique:users',
            'password' => 'required|string|min:6',
            'email' => 'required|string|email|unique:users',
            'nama_lengkap' => 'required|string',
            'nim' => 'required|string|unique:mahasiswa,nim',
            'tanggal_lahir' => 'required|date',
            'fakultas' => 'required|string',
            'program_studi' => 'required|string',
            'angkatan' => 'required|string',
            'alamat' => 'required|string'
        ]);

        \Log::info('Data request: ', $request->all());

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => $validator->errors()
            ], 422);
        }

        $user = User::create([
            'username' => $request->username,
            'password' => Hash::make($request->password),
            'email' => $request->email,
            'nama_lengkap' => $request->nama_lengkap,
        ]);

        // Buat entri mahasiswa baru
        $mahasiswa = Mahasiswa::create([
            'id_user' => $user->id,
            'nim' => $request->nim,
            'nama_mahasiswa' => $request->nama_lengkap,
            'tanggal_lahir'=> $request->tanggal_lahir,
            'fakultas' => $request->fakultas,
            'program_studi' => $request->program_studi,
            'angkatan' => $request->angkatan,
            'alamat' => $request->alamat,
        ]);

        return response()->json(['message' => 'User registered successfully', 'user' => $user], 201);
    }

    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');

        try {
            if (!$token = JWTAuth::attempt($credentials)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid email or password'
                ], 401);
            }
        } catch (JWTException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Could not create token'
            ], 500);
        }

        $user = JWTAuth::user();

        return response()->json([
            'success' => true,
            'message' => 'Login success!',
            'data' => [
                'id' => $user->id,
                'nama' => $user->nama_lengkap,
                'role' => $user->role,
                'token' => $token,
            ]
        ], 200);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'username' => 'sometimes|string|unique:users,username,' . $id,
            'email' => 'sometimes|string|email|unique:users,email,' . $id,
            'nama_lengkap' => 'sometimes|string',
        ]);

        $user = User::findOrFail($id);
        $user->update($request->only('username', 'email', 'nama_lengkap'));

        return response()->json(['message' => 'User updated successfully', 'user' => $user]);
    }
}