<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use App\Models\Transaksi;
use App\Models\Mahasiswa;

class TransaksiController extends Controller
{
    // Tampilkan semua transaksi milik mahasiswa yang sedang login
    public function index()
    {
        $user = auth()->user();
        $mahasiswa = $user->mahasiswa;

        if (!$mahasiswa) {
            return response()->json(['message' => 'Mahasiswa tidak ditemukan'], 404);
        }

        $transaksi = Transaksi::where('id_mahasiswa', $mahasiswa->id_mahasiswa)
            ->with('tagihan') // opsional, jika ingin detail tagihan
            ->orderBy('tanggal_bayar', 'desc')
            ->get();

        return response()->json([
            'success' => true,
            'data' => $transaksi
        ]);
    }

    // Tampilkan detail transaksi tertentu
    public function show($id)
    {
        $user = auth()->user();
        $mahasiswa = $user->mahasiswa;

        $transaksi = Transaksi::where('id', $id)
            ->where('id_mahasiswa', $mahasiswa->id_mahasiswa)
            ->with('tagihan')
            ->first();

        if (!$transaksi) {
            return response()->json(['message' => 'Transaksi tidak ditemukan'], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $transaksi
        ]);
    }

    // Mahasiswa membayar tagihan → update transaksi
    public function update(Request $request, $id)
    {
        $user = auth()->user();
        $mahasiswa = $user->mahasiswa;

        $transaksi = Transaksi::where('id', $id)
            ->where('id_mahasiswa', $mahasiswa->id_mahasiswa)
            ->first();

        if (!$transaksi) {
            return response()->json(['message' => 'Transaksi tidak ditemukan'], 404);
        }

        if ($transaksi->status === 'sudah bayar') {
            return response()->json(['message' => 'Transaksi sudah dibayar'], 400);
        }

        $transaksi->update([
            'status'        => 'sudah bayar',
            'tanggal_bayar' => Carbon::now(),
            // 'jumlah_bayar' => $request->jumlah_bayar ?? $transaksi->jumlah_bayar // opsional jika pembayaran parsial
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Pembayaran berhasil',
            'data' => $transaksi
        ]);
    }
}
