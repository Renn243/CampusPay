<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('riwayat_pembayaran', function (Blueprint $table) {
            $table->id('id_riwayat');
            $table->foreignId('id_transaksi')
                  ->constrained('transaksi','id_transaksi')
                  ->onDelete('cascade');
            $table->foreignId('id_mahasiswa')
                  ->constrained('mahasiswa','id_mahasiswa')
                  ->onDelete('cascade');
            $table->text('deskripsi');
            $table->decimal('jumlah',15,2);
            $table->dateTime('tanggal_riwayat');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('riwayat_pembayaran');
    }
};
